def main():
    import mmpdblib.commandline
    mmpdblib.commandline.main()


if __name__ == "__main__":
    main()
